# Dochoithuvi-Pro v6.8.6 FinalGate MicroShield RC1 Fix2 Watchdog — GitHub Public

## Bản sửa Watchdog từ báo cáo thực tế

Các báo cáo Kindle cho thấy engine và Watchdog đều đã tự dừng trước khi người dùng bấm STOP. File Watchdog ghi `WATCHDOG_REASON=STALE_HEARTBEAT` với tuổi heartbeat khoảng 1.551–1.569 giây.

Đây không phải bằng chứng engine bị treo. Khi Kindle để yên, engine có thể đang ngủ trong `read()` để chờ sự kiện Goodix, vì vậy heartbeat không đổi dù tiến trình vẫn hoạt động bình thường. Fix1 đã coi mọi heartbeat cũ hơn 15 giây là lỗi và giết nhầm engine.

Fix2 chuyển sang Watchdog nhận biết trạng thái:

- `QUIET`, `WATCH`, `SAFETY_PAUSE`: heartbeat cũ chỉ được theo dõi, tuyệt đối không giết engine vì máy không có thao tác.
- `MICRO_GATE`: đây là trạng thái can thiệp có giới hạn tối đa 2,5 giây. Watchdog còn đối chiếu tag gate cuối trong report. `GATE_END` hoặc `GATE_FAIL` được coi là đã nhả an toàn; chỉ khi tag cuối vẫn là `GATE_START` (hoặc report không đọc được), heartbeat kẹt quá 12 giây và lặp lại hai lần, Watchdog mới dừng engine để đóng file descriptor và nhả `EVIOCGRAB`.
- Không có heartbeat đầu tiên: chờ 30 giây và xác nhận hai lần liên tiếp trước khi dừng engine theo cơ chế fail-open.
- Launcher xác nhận Watchdog thực sự đã chạy. Nếu Watchdog không khởi động, launcher dừng engine ngay để cảm ứng hoạt động bình thường.

## GitHub public release

- OTA identity: `8.3`.
- GitHub tag: `v6.8.6-finalgate-fix2`.
- `manifest.txt` được ký RSA-3072/SHA-256 và xác minh bằng `secure_update_public.pem`.
- Private signing key không nằm trong gói khách hàng.
- Google Drive token không nằm trong gói public. Kindle đọc cấu hình tại `/mnt/us/documents/dochoithuvi_drive_token.conf`.

## Menu

```text
01. GhostGuard FinalGate MicroShield — START
02. GhostGuard FinalGate MicroShield — STOP
03. Dừng & gửi báo cáo Cloud
05. Báo cáo & Chẩn đoán pin
06. MagicAds
07. Dọn dẹp báo cáo/log cũ
09. Cập nhật phiên bản mới
```

## Cơ chế FinalGate

1. Đọc raw Goodix song song với Xorg, không grab trong trạng thái bình thường.
2. Chia màn hình thành lưới 8 × 12 và chấm điểm từng vùng.
3. Điểm vùng tự giảm; khi hết dấu hiệu bất thường, trạng thái trở về `QUIET`.
4. Chỉ dùng `EVIOCGRAB` ngắn khi bằng chứng lặp đủ mạnh:
   - `650 ms`: vùng nóng đã học và contact lặp lại;
   - `1400 ms`: burst cùng vùng;
   - `2500 ms`: storm toàn cục.
5. Tối đa 4 gate trong 60 giây. Vượt giới hạn chuyển sang monitor-only 60 giây.
6. STOP, crash hoặc Watchdog xác nhận `MICRO_GATE` bị kẹt sẽ đóng file descriptor và nhả `EVIOCGRAB`.

## Báo cáo Watchdog

Báo cáo cố định:

```text
/mnt/us/documents/DCPRO_FINALGATE_WATCHDOG.txt
```

Heartbeat runtime của Watchdog:

```text
/tmp/dcpro_finalgate_watchdog_heartbeat.txt
```

Các trường mới gồm `WATCHDOG_POLICY`, `STALE_IDLE_HEARTBEAT_ACTION`, `ENGINE_HEARTBEAT_STATE`, `ENGINE_PROCESS_STATE`, `ENGINE_EXIT_REASON` và `WATCHDOG_EXIT_REASON`.

## Các sửa lỗi Fix1 vẫn được giữ nguyên

- Nhận đúng `Handlers=event1 perfmgr` và Goodix tại `/dev/input/event1`.
- Fallback sysfs an toàn cho Goodix/GT6861/GTX8/touchscreen.
- STOP xác minh riêng engine và Watchdog.
- Cloud retry queue cũ, migrate `V686_`/`FINALGATE_`, copy atomic, gzip trên 2 MB, giới hạn 8 MiB, thử gửi ba lần và giữ báo cáo local.

## Kiểm tra sau khi cài

1. Bấm START và kiểm tra `DCPRO_FINALGATE_STATUS.txt` có `STATUS=RUNNING` cùng `WATCHDOG_POLICY=STATE_AWARE_FAIL_OPEN_FIX2`.
2. Để máy không thao tác ít nhất 30 phút. Engine và Watchdog phải vẫn chạy; không được xuất hiện `WATCHDOG_REASON=STALE_HEARTBEAT`.
3. Dùng máy bình thường, sau đó bấm STOP. Báo cáo phải có `STOP_RESULT=SUCCESS`.
4. Bấm “Dừng & gửi báo cáo Cloud” để gửi report, Watchdog report, status và stop report.
