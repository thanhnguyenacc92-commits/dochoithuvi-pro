DOCHOITHUVI-PRO v7.2 - PPW4 LAUNCH FIX

Nếu report chính vẫn chỉ thấy ENGINE ROUTER mà không thấy RUNTIME:
- Gửi thêm file:
  /mnt/us/documents/DCPRO_1CLICK_ENGINE_LAUNCH_DEBUG.txt

Bản v7.2 sửa router để gọi engine bằng:
  sh ppw4_faststable_guardian_start.sh

Thay vì exec trực tiếp, tránh lỗi không start khi script bị mất quyền execute sau khi copy qua USB.
