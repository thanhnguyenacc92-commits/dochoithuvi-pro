DOCHOITHUVI-PRO v7.7 - ALWAYS ON MONITOR

Lý do sửa:
- Bản cũ nếu QUIET đủ lâu sẽ tự OFF.
- Máy ghost touch thường yên một lúc rồi loạn lại.
- Khi đã OFF thì không tự bật lại được.

Bản v7.7:
- QUIET đủ lâu -> Standby Monitor.
- Không xóa PID.
- Không xóa mode.
- Không ghi OFF vào profile.
- Không exit daemon.
- Vẫn theo dõi nền để bắt cơn ghost touch quay lại.

Tắt bằng tay:
  02. Tắt 1-Click Auto Fix Touch
