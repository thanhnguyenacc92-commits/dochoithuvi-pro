DOCHOITHUVI-PRO v7.5 - BASIC STORMHOLD

Dành cho máy Basic 11/12 loạn cảm ứng rất nặng theo từng cơn.

Ý tưởng:
- Nếu máy STORM vài lần rồi tự yên 1-2 vòng, bản cũ sẽ hạ mức xuống HEAVY/MILD quá sớm.
- Bản v7.5 bật Storm Hold để giữ chế độ STORM lâu hơn.
- Nếu report hiện hardware_suspect=1, nên coi máy có khả năng lỗi phần cứng/nhiễu panel Goodix nặng.

Report cần gửi:
 /mnt/us/documents/DCPRO_1CLICK_AUTO_FIX_TOUCH_REPORT.txt
