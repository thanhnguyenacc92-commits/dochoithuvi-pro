DOCHOITHUVI-PRO v7.4 - BASIC HIGHBURST AGGRESSIVE

Dành cho máy Basic Goodix loạn theo từng cơn mạnh.

Dấu hiệu từ report:
- IRQ có nhịp +75/10s.
- EVDEV có nhịp +140/10s.
- Hai nhịp còn lại có thể bằng 0 nên bản cũ xếp MILD.

v7.4:
- Nếu EVDEV và IRQ cùng tăng mạnh, không coi là chạm lẻ nữa.
- Nâng tối thiểu HEAVY để khóa/mở touch nhanh hơn.
- Vòng nền kiểm tra nhanh hơn để không chờ quá lâu khi máy đang loạn.
