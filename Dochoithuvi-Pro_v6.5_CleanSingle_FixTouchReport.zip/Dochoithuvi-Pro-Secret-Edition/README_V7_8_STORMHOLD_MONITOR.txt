DOCHOITHUVI-PRO v7.8 - STORMHOLD MONITOR

Bản này dành cho các máy Basic loạn rất nặng nhưng có các khoảng yên ngắn.

Khác v7.6:
- v7.6 giữ STORM bằng StormHold, nhưng vẫn recovery STORM ở cả chu kỳ RAW=QUIET.
- v7.8 giữ STORM để không hạ mức quá sớm, nhưng nếu chu kỳ hiện tại yên thật thì không khóa cảm ứng nữa.

Report kỳ vọng:
- Phân loại RAW hiện tại: QUIET
- Phân loại tổng hợp/giữ mức: STORM
- StormHold Monitor: RAW=QUIET -> không khóa cảm ứng, chỉ tiếp tục theo dõi.
