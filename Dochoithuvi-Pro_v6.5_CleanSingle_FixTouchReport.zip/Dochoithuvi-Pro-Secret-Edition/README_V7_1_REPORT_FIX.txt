DOCHOITHUVI-PRO v7.1 - PPW4 REPORT FIX

Khi bấm 01. 1-Click Auto Fix Touch trên PPW4:
- Router vẫn ghi:
  /mnt/us/documents/DCPRO_1CLICK_AUTO_FIX_TOUCH_ROUTER.txt

- Report chính giờ sẽ có cả runtime:
  /mnt/us/documents/DCPRO_1CLICK_AUTO_FIX_TOUCH_REPORT.txt

Nên đợi 1-2 phút sau khi bật 1-Click rồi lấy report để có log IRQ/QUIET/MILD/HEAVY/STORM.
