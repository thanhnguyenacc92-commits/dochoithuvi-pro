DOCHOITHUVI-PRO v7.6 - CLEAN SH + PPW4 FASTSTABLE INTEGRATED

Mục tiêu:
1. Xóa file .sh thừa.
2. Giữ menu gọn 10 mục.
3. Tích hợp PPW4 FastStable Guardian vào cùng nút:
   01. 1-Click Auto Fix Touch

Điểm sửa:
- Không xóa ppw4_faststable_guardian_start.sh nữa.
- File này là engine PPW4 thật.
- Nếu file ngoài vẫn thiếu do cài đè lỗi, router còn embedded fallback bên trong auto_adaptive_guardian.sh.

Nên cài đè v7.6, sau đó có thể chạy:
07. Dọn dẹp báo cáo/log cũ

Cleaner v7.6 sẽ xóa helper PPW4 cũ, nhưng giữ engine PPW4 chính.
