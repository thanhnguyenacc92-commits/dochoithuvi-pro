DOCHOITHUVI-PRO v7.3 - PPW4 EMBEDDED FALLBACK

Lý do:
- Trên máy PPW4 test, router tìm:
  /mnt/us/extensions/Dochoithuvi-Pro-Secret-Edition/bin/ppw4_faststable_guardian_start.sh
  nhưng file không tồn tại.

Cách sửa:
- Router v7.3 vẫn tìm file engine ngoài.
- Nếu thiếu, router tự chạy PPW4 FastStable engine nhúng bên trong chính auto_adaptive_guardian.sh.

Kỳ vọng report:
 /mnt/us/documents/DCPRO_1CLICK_AUTO_FIX_TOUCH_REPORT.txt

phải có dòng:
 PPW4 FASTSTABLE GUARDIAN v7.3 - EMBEDDED RUNTIME
