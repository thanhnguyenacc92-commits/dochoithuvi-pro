DOCHOITHUVI-PRO v6.8 - SMARTPROFILE TUNED

Report duy nhất:
 /mnt/us/documents/DCPRO_1CLICK_AUTO_FIX_TOUCH_REPORT.txt

SmartProfile lưu theo serial:
 /mnt/us/.dcpro_touch_profile/<SERIAL>.profile

Điểm tối ưu:
 - Máy nhẹ: MILD đầu tiên chỉ monitor, hạn chế khóa cảm ứng.
 - Máy storm nặng: tự vào HardwareSuspect Monitor.
 - HardwareSuspect: không khóa khi RAW=QUIET/MILD.
 - PPW4: FastStable trong cùng nút 1-Click.
 - QUIET không Auto OFF.
