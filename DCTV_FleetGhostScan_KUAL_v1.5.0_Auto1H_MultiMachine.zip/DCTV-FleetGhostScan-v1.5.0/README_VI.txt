DCTV FLEET GHOST SCAN v1.5.0
================================

MỤC ĐÍCH
--------
Kiểm tra hàng chục Kindle mà không cần bấm MARK thủ công.

Mỗi máy tự:
- tạo MACHINE_ID ổn định từ mã băm riêng tư;
- theo dõi Goodix thụ động;
- tự nhận diện contact đáng ngờ sau thời gian chuẩn bị;
- tạo SUMMARY và một dòng FLEET_INDEX.csv;
- không lưu serial đầy đủ.

QUY TRÌNH CHUẨN CHO MỖI MÁY
----------------------------
1. Đặt thời gian tự ngủ của Kindle thành 1 giờ.
2. Chép DCTV-FleetGhostScan-v1.5.0 vào /mnt/us/extensions/
3. Trong KUAL chọn:
   A. AUTO 1 giờ - mở sách trong 2 phút rồi không chạm
4. Trong 2 phút đầu:
   - mở đúng một cuốn sách;
   - đặt máy lên mặt phẳng;
   - sau đó tuyệt đối không chạm màn hình.
5. Để nguyên máy trong 1 giờ.

Không cần bấm MARK.

NHẬN DIỆN GHOST TỰ ĐỘNG
-----------------------
Sau 2 phút chuẩn bị, tool coi các contact ngắn, đứng yên, rất ít frame là
AUTO_GHOST_SUSPECT.

Kết quả:
- CLEAN: không có contact sau thời gian chuẩn bị.
- GHOST_SUSPECTED: một contact đáng ngờ.
- GHOST_LIKELY: từ hai contact đáng ngờ.
- GHOST_STORM: cụm dồn nhanh hoặc lặp cùng ô màn hình.
- MOVING_CONTACT_DETECTED: có thao tác di chuyển; cần xem lại vì có thể ai đó
  đã chạm máy hoặc là ghost dạng kéo.

Kết quả chỉ đáng tin khi không ai chạm máy sau 2 phút chuẩn bị.

NHẬN DIỆN TỪNG MÁY
-------------------
Tool tự tạo dạng:

  MACHINE_ID=MT8110_12KYTUHASH

và ghi vào:

  /mnt/us/documents/DCTV_MACHINE_ID.txt

Có thể tạo thêm DCTV_MACHINE_LABEL.txt với MAY01, MAY02... nhưng không bắt
buộc. Tên file vẫn có MACHINE_ID nên không trộn máy.

FILE QUAN TRỌNG
---------------
Mỗi phiên có:
- *_SUMMARY.txt          kết luận ngắn gọn;
- *_AUTO_EVENTS.csv      danh sách contact tự phát hiện;
- *_RAW.txt              dữ liệu thô;
- *_REPORT.txt           gesture report theo từng segment;
- *_DEVICE.txt           thông tin máy, serial đã REDACTED;
- *_KUAL.txt             trạng thái;
- DCTV_FLEET_INDEX.csv   một dòng tổng hợp trên máy đó.

Khi test nhiều máy, trước tiên chỉ cần gom *_SUMMARY.txt và DCTV_FLEET_INDEX.csv.
Chỉ máy nào bị SUSPECTED/LIKELY/STORM mới cần lấy thêm RAW và AUTO_EVENTS.

AN TOÀN
-------
- EVIOCGRAB=NO
- XTEST=NO
- UINPUT=NO
- Không sửa IRQ
- Không restart Xorg
- Không sửa file hệ thống
- Không autostart

GHI CHÚ KỸ THUẬT
----------------
Native reader được chạy theo các segment liên tiếp cho đến đủ 62 phút
(2 phút chuẩn bị + 60 phút quan sát). Vì vậy bài test vẫn hoàn tất ngay cả khi
một segment nội bộ kết thúc sớm.

Gói đã được kiểm tra cấu trúc, shell, ARM, no-grab patch và ZIP; chưa được
chạy trực tiếp trên Kindle thật bởi người tạo gói.
