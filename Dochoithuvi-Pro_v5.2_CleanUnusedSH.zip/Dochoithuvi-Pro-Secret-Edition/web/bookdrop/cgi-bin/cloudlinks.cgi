#!/bin/sh
DOC="/mnt/us/documents"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONF="$DOC/dochoithuvi_bookcloud_links.txt"
TMP="/tmp/dochoithuvi_cloudlinks_post.$$"
mkdir -p "$DOC"

decode_form(){
    # Chấp nhận form: links=<urlencoded text>
    cat > "$TMP"
    VAL="$(sed 's/^.*links=//' "$TMP" | sed 's/&.*$//')"
    # Decode đủ dùng cho URL/text phổ biến.
    VAL="$(echo "$VAL" | sed 's/+/ /g;s/%0D//Ig;s/%0A/\n/Ig;s/%7C/|/Ig;s/%3A/:/Ig;s/%2F/\//Ig;s/%3F/?/Ig;s/%3D/=/Ig;s/%26/\&/Ig;s/%23/#/Ig;s/%25/%/Ig;s/%20/ /Ig;s/%2B/+/Ig;s/%2C/,/Ig')"
    printf "%s\n" "$VAL"
    rm -f "$TMP"
}

echo "Content-Type: text/plain; charset=utf-8"
echo "Cache-Control: no-store"
echo ""

case "$REQUEST_METHOD" in
GET)
    if [ -f "$CONF" ]; then cat "$CONF"; else cat "$ROOT/bookcloud_links.txt" 2>/dev/null; fi
    ;;
POST)
    {
        echo "# DOCHOITHUVI BOOKCLOUD LINKS"
        echo "# Mỗi dòng: URL|Tên hiển thị"
        echo "# Tạo/sửa từ BookDrop trên điện thoại"
        decode_form | sed '/^[[:space:]]*$/d'
    } > "$CONF"
    cp "$CONF" "$ROOT/bookcloud_links.txt" 2>/dev/null || true
    sync
    echo "OK: đã lưu kho sách cá nhân vào Kindle."
    echo "$CONF"
    ;;
*)
    echo "Unsupported method"
    ;;
esac
exit 0
