#!/bin/sh
DOC="/mnt/us/documents"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CONF="$DOC/dochoithuvi_sendtokindle_email.conf"
TMP="/tmp/dochoithuvi_stk_email.$$"
mkdir -p "$DOC"

decode_email(){
    cat > "$TMP"
    VAL="$(sed 's/^.*email=//' "$TMP" | sed 's/&.*$//')"
    VAL="$(echo "$VAL" | sed 's/+/ /g;s/%40/@/Ig;s/%2E/./Ig;s/%2D/-/Ig;s/%5F/_/Ig;s/%2B/+/Ig;s/%20/ /Ig')"
    echo "$VAL" | tr -cd 'A-Za-z0-9._%+-@'
    rm -f "$TMP"
}

echo "Content-Type: text/plain; charset=utf-8"
echo "Cache-Control: no-store"
echo ""

EMAIL="$(decode_email)"
if echo "$EMAIL" | grep -Eq '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'; then
    echo "$EMAIL" > "$CONF"
    echo "$EMAIL" > "$ROOT/sendtokindle_email.txt" 2>/dev/null || true
    sync
    echo "OK: đã lưu email Send to Kindle:"
    echo "$EMAIL"
else
    echo "LỖI: email không hợp lệ."
fi
exit 0
