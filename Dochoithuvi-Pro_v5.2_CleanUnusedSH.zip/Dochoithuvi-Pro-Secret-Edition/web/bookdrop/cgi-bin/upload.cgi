#!/bin/sh
DOC="/mnt/us/documents"; LOG="/mnt/us/dochoithuvi_bookdrop_upload.log"; TMP="/tmp/dochoithuvi_bookdrop_post.txt"; B64="/tmp/dochoithuvi_bookdrop_upload.b64"; ERR="/tmp/dochoithuvi_bookdrop_err.txt"; EXT_ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"; mkdir -p "$DOC"

url_decode_name(){ echo "$1" | sed 's/%20/ /g;s/%28/(/g;s/%29/)/g;s/%5B/[/g;s/%5D/]/g;s/%2E/./g;s/%2D/-/g;s/%5F/_/g;s/%2B/+/g;s/%2C/,/g'; }
safe_name(){ basename "$1" | tr -cd 'A-Za-z0-9._- ()[],'; }

form_value(){ tr '&' '\n' < "$TMP" | grep -m1 "^$1=" | sed "s/^$1=//"; }
allowed_ext(){ E="$(echo "$1" | awk -F. '{print tolower($NF)}')"; case "$E" in azw|azw3|mobi|prc|kfx|pdf|txt|cbz|cbr) return 0;; esac; return 1; }
unique_target(){ NAME="$1"; EXT="$(echo "$NAME" | awk -F. '{print tolower($NF)}')"; TARGET="$DOC/$NAME"; BASE="$(echo "$NAME" | sed 's/.[^.]*$//')"; SUF="$EXT"; N=1; while [ -e "$TARGET" ]; do TARGET="$DOC/$BASE"_"$N.$SUF"; N=$((N+1)); done; echo "$TARGET"; }
reject_ext(){ NAME="$1"; echo "File không được hỗ trợ: $NAME"; echo "BookDrop chỉ nhận MOBI/AZW3/AZW/KFX/PRC/PDF/TXT/CBZ/CBR."; echo "EPUB/DOC/DOCX nên dùng Send to Kindle hoặc convert trước khi gửi."; }
echo "Content-Type: text/plain; charset=utf-8"; echo ""

if [ -n "$HTTP_X_FILE_NAME" ]; then
    NAME="$(url_decode_name "$HTTP_X_FILE_NAME")"; NAME="$(safe_name "$NAME")"; [ -z "$NAME" ] && NAME="upload_book.bin"
    if ! allowed_ext "$NAME"; then reject_ext "$NAME"; exit 0; fi
    TARGET="$(unique_target "$NAME")"
    if cat > "$TARGET"; then
        SIZE="$(wc -c < "$TARGET")"; sync
        echo "Upload thành công!"
        echo "File: $(basename "$TARGET")"
        echo "Dung lượng: $SIZE bytes"
        echo "Đã lưu vào Documents của Kindle."
        echo "Gợi ý bìa sách: nếu Library chưa hiện cover, chạy BookDrop > Làm mới Library / bìa sách."
        echo "Chế độ: gửi trực tiếp, không base64."
        echo "$(date) uploaded $TARGET size=$SIZE direct=1" >> "$LOG"
    else
        echo "Upload lỗi khi ghi file."; rm -f "$TARGET"
    fi
    exit 0
fi

cat > "$TMP"
RAWNAME="$(form_value filename | head -c 240)"
NAME="$(url_decode_name "$RAWNAME")"; NAME="$(safe_name "$NAME")"; [ -z "$NAME" ] && NAME="upload_book.bin"
if ! allowed_ext "$NAME"; then reject_ext "$NAME"; rm -f "$TMP"; exit 0; fi
TARGET="$(unique_target "$NAME")"
sed 's/^.*&data=//' "$TMP" | tr '_-' '/+' > "$B64"; LEN="$(wc -c < "$B64")"; MOD=$((LEN % 4)); [ "$MOD" = "2" ] && echo "==" >> "$B64"; [ "$MOD" = "3" ] && echo "=" >> "$B64"
if base64 -d "$B64" > "$TARGET" 2>"$ERR" || base64 --decode "$B64" > "$TARGET" 2>"$ERR" || { command -v busybox >/dev/null 2>&1 && busybox base64 -d "$B64" > "$TARGET" 2>"$ERR"; }; then SIZE="$(wc -c < "$TARGET")"; sync; echo "Upload thành công!"; echo "File: $(basename "$TARGET")"; echo "Dung lượng: $SIZE bytes"; echo "Đã lưu vào Documents của Kindle."; echo "Gợi ý bìa sách: nếu Library chưa hiện cover, chạy BookDrop > Làm mới Library / bìa sách."; echo "Chế độ: tương thích base64."; echo "$(date) uploaded $TARGET size=$SIZE direct=0" >> "$LOG"; else echo "Upload lỗi khi giải mã base64."; cat "$ERR"; rm -f "$TARGET"; fi
rm -f "$TMP" "$B64" "$ERR"; exit 0
