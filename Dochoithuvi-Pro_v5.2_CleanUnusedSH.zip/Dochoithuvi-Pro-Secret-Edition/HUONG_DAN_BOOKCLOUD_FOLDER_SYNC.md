BOOKCLOUD - ĐỒNG BỘ CẢ THƯ MỤC CLOUD
====================================

Không sync cả folder chỉ bằng link folder Google Drive/Dropbox/Terabox.

Cách ổn định:
1. Tạo Google Apps Script từ file BOOKCLOUD_GOOGLE_APPS_SCRIPT_TEMPLATE.js.
2. Sửa FOLDER_ID.
3. Deploy Web App.
4. Dán vào Kho sách cá nhân:
   manifest:https://script.google.com/macros/s/XXXX/exec|Kho Google Drive

BookCloud sẽ tải manifest text/plain, mỗi dòng:
URL|Tên file

Sau đó tự tải từng file về /documents.
