# Dochoithuvi-Pro_v4.0

## v4.0 - Package sạch hơn
- Xóa các script không còn nằm trong menu và không được gọi phụ trợ: `final_full_diagnostic_report.sh`, `reset_goodix_ultra_reboot.sh`, `touch_model_detect.sh`.
- Giữ lại các script common cần thiết cho license, touch IRQ, BookDrop server và Send to Kindle.
- Không đổi thuật toán Guardian/BookDrop so với v3.9.

## v3.9 - Gọn menu, bỏ E-Ink và màn chờ
- Bỏ nhóm `Kiểm tra màn hình E-Ink` khỏi menu và khỏi package vì Kindle Basic 2022 không expose contrast/waveform đủ an toàn để can thiệp kiểu Boox.
- Bỏ nhóm `Màn chờ / Ảnh bìa` khỏi menu và khỏi package. Display Cover gốc nên bật trong Settings của Kindle khi máy đã tắt ads; KUAL không ép bật ổn định trên mọi firmware.
- Renumber menu chính còn 7 nhóm, BookDrop chuyển thành mục `07. Dochoithuvi BookDrop`.
- Giữ trọng tâm bản Pro ở các phần có hiệu quả thực tế: fix cảm ứng/IRQ, pin, dọn dẹp/cứu hộ, license, chặn OTA và BookDrop.

## v3.8 - Basic 2022 IRQ map, BookDrop Send to Kindle share
- Basic 2022 firmware 5.19.x map dòng `MT_SYSIRQ 127 ... i2c-mt65xx` thành IRQ line thật trong `/proc/interrupts`, tránh lỗi `IRQ=0` do tìm nhầm `127:`.
- BookDrop chọn file thông minh hơn: EPUB/DOC/DOCX mở luồng Send to Kindle bằng Web Share trên điện thoại nếu trình duyệt hỗ trợ.
- MOBI/AZW3/AZW/KFX/PRC/PDF/TXT/CBZ/CBR vẫn upload trực tiếp vào Kindle qua Wi-Fi.
- Dọn báo cáo bổ sung các file trạng thái/log mới của BookDrop, Send to Kindle, PPW4 và probe Basic 2022.

## v3.7 - Send to Kindle và màn chờ
- BookDrop thêm khối Send to Kindle: tự dò email Kindle nếu firmware lưu được, hoặc đọc từ `documents/dochoithuvi_sendtokindle_email.conf`.
- Trang BookDrop cho chọn EPUB/DOC/DOCX nhưng không upload trực tiếp; hướng sang Send to Kindle để Amazon convert.
- Thêm mục `10. Màn chờ / Ảnh bìa`: trạng thái, cài ảnh chờ tùy chỉnh, xóa ảnh chờ tùy chỉnh.
- Ảnh chờ tùy chỉnh dùng screensaver hack/linkss nếu máy có; tool không gỡ/bypass Special Offers.

## v3.6 - Menu gọn và BookDrop nhanh hơn
- Rút gọn mục Chẩn đoán cảm ứng chung: bỏ Reset Goodix Ultra + Reboot khỏi menu để tránh bấm nhầm thao tác mạnh.
- Bỏ Xuất báo cáo kỹ thuật tổng hợp khỏi mục 06. Dọn dẹp & Cứu hộ.
- Thêm Refresh nhanh E-Ink; giữ Làm sạch ghosting sâu và E-Ink Doctor để nghiên cứu node waveform/panel.
- BookDrop chuyển sang upload nhị phân trực tiếp, không base64, nhẹ RAM hơn và phù hợp file lớn hơn.
- EPUB vẫn nên dùng Send to Kindle hoặc convert trước khi gửi vào BookDrop.

## v3.5 - Chặn nhầm nhánh PPW4 trên Basic
- Chặn PPW4 Fast Stable Guardian/Recovery chạy trên máy không phải Kindle Paperwhite 4.
- Nếu bấm nhầm PPW4 trên Basic 2022/2024, tool sẽ báo rõ và thoát.
- Khi bật Basic Smooth/Strong Guardian, tool tự dừng PID PPW4 FastStable cũ nếu còn sót.
- Tránh tình trạng Basic 2022 sinh file `ppw4_faststable_guardian.log` gây nhầm báo cáo.

## v3.4 - Strong Rescue cooldown watch
- Nghiên cứu log Basic 2022 firmware 5.19.2: storm được xử lý nhưng có thể tái phát trong lúc cooldown.
- Strong Rescue v1.9 đổi sang kiểm tra 15 giây, ngưỡng storm theo nhịp ngắn hơn.
- Cooldown không ngủ mù nữa: vẫn theo dõi mỗi 10 giây và chen rescue nếu IRQ tăng mạnh.
- Sửa lỗi cooldown kép khiến burst ngay sau khi đã nghỉ cooldown vẫn bị bỏ qua thêm một vòng.

## v3.3 - Basic proc-touch hybrid
- Sửa lỗi Basic 2022 firmware mới không có `goodix irq_info`, báo cáo chỉ hiện "Không ghi được irq_info".
- Basic Smooth Guardian v1.9 tự fallback sang `/proc/touch` + `/proc/interrupts` khi cần.
- IRQ Recovery thủ công, Status, Tắt Guardian và Chẩn đoán Ghost Touch cũng dùng chung cơ chế hybrid.
- Báo cáo Basic có `/proc/touch` không còn hiện nhầm là PPW4-style.

## v3.2 - BookDrop receive-only
- Bỏ cơ chế convert trong BookDrop.
- Bỏ mục convert ebook khỏi menu Dochoithuvi BookDrop.
- Giao diện điện thoại/máy tính ghi rõ: chỉ nhận MOBI/AZW3/AZW/KFX/PRC/PDF/TXT/CBZ/CBR.
- EPUB cần convert trước khi gửi nếu đọc bằng thư viện Kindle gốc.

## v3.1 - Basic Smooth Guardian
- Basic 2022/2024 chuyển sang Smooth Guardian để dùng hằng ngày: theo dõi trước, chỉ micro lock 1 giây khi cần.
- Strong Rescue tách riêng cho trường hợp máy đang loạn nặng, vẫn có thể khựng 3-8 giây.
- Bỏ mục Nhận diện dòng máy / Recovery phù hợp khỏi nhóm Kiểm tra & Fix lỗi cảm ứng.
- Trạng thái/tắt/cứu hộ nhận diện được cả Smooth Guardian và Strong Rescue.

## v3.0 - License anti-rollback và BookDrop no-TXT
- Thêm anti-rollback cho license offline: lưu ngày Kindle đã thấy cao nhất, phát hiện chỉnh lùi thời gian.
- License mới hỗ trợ `issued_at` được ký chung với chữ ký v3; license cũ vẫn chạy theo format legacy.
- BookDrop không tự tạo TXT fallback nữa.
- Từ v3.2 đã bỏ cơ chế convert trong BookDrop; EPUB cần convert trước khi gửi.

## v2.9 - PPW4 device mapping
- Map serial prefix G000PP thành Kindle Paperwhite 4 / 10th Gen (2018).
- Báo cáo PPW4 không còn hiện Thiết bị: UNKNOWN với dòng G000PP.
- Cập nhật tiêu đề báo cáo tổng hợp và cứu hộ nhanh sang v2.9.

## v2.8 - Menu cleanup
- Bỏ "Xuất báo cáo kỹ thuật tổng hợp" khỏi màn hình chính.
- Từ v3.6 đã bỏ báo cáo kỹ thuật tổng hợp khỏi mục 06. Dọn dẹp & Cứu hộ.
- Đổi mục 09 thành Dochoithuvi BookDrop.

## v2.7 - Basic UI Storm Guard
- Nâng Basic IRQ Guardian lên v1.7.
- Sau recovery, nếu IRQ vẫn tăng cao, tự khóa cảm ứng ngắn 3-5 giây theo từng nhịp, tối đa 3 nhịp rồi mở lại.
- Khi tắt Guardian hoặc tiến trình dừng, tool force mở lại cảm ứng nếu ghi được irq_info.
- Mục tiêu: giảm ghost touch kéo giao diện/Quick Settings và hạn chế crash UI trên Basic 2022.

## v2.6 - BookDrop copy cleanup
- Dọn bớt chữ giải thích trên giao diện điện thoại.

## v2.5 - EPUB TXT fallback (đã bỏ)
- Tính năng TXT fallback cũ đã bỏ từ v3.0; v3.2 bỏ hẳn cơ chế convert trong BookDrop.

## v2.4 - BookDrop auto convert (đã bỏ)
- Tính năng auto convert cũ đã bỏ từ v3.2; BookDrop hiện chỉ nhận và lưu file Kindle hỗ trợ trực tiếp.

## v2.3 - BookDrop progress
- Thêm tiến trình upload MB/s và thời gian còn lại.
- Mục convert ebook cũ đã bỏ khỏi menu từ v3.2.

## v2.2 - BookDrop format guidance
- Cảnh báo HTTP nội bộ.
- Cảnh báo EPUB/DOCX/CBZ cần KOReader hoặc convert nếu đọc bằng Kindle gốc.

## v2.1 - BookDrop firewall
- Mở firewall Kindle cho port BookDrop nếu có iptables.
- Thêm mục chẩn đoán mạng BookDrop.

## v2.0 - BookDrop LAN bind
- Thử bind BookDrop vào IP thật và 0.0.0.0.
- Giữ Kindle thức khi bật BookDrop.
- Báo rõ đã thấy request từ điện thoại chưa.

## v1.9 - BookDrop port fallback
- Dọn tiến trình BookDrop cũ mạnh hơn.
- Tự đổi cổng nếu 8080 bị chiếm.
- Dò IP bổ sung và báo cáo rõ Port đang dùng.

## v1.8 - BookDrop IP và upload
- Sửa lỗi IP UNKNOWN trong báo cáo BookDrop.
- Sửa lỗi JavaScript trang upload.
- Netcat fallback ghi log request và thử nhiều cú pháp listener hơn.

Bản Việt hóa dạng Kindle Service Toolkit cho KUAL.

Nhóm chính bản Final Clean:
1. Kiểm tra & Fix lỗi cảm ứng
3. Báo cáo & Chẩn đoán pin
4. Kiểm tra màn hình E-Ink
5. Khởi động lại Kindle
6. Dọn dẹp & Cứu hộ
7. Bản quyền / Serial
8. Chặn cập nhật Kindle
9. Dochoithuvi BookDrop

File quan trọng:
- Documents/dochoithuvi_final_full_report.txt
- Documents/bao_cao_chan_doan_pin.txt
- Documents/bao_cao_man_hinh_eink.txt
- Documents/dochoithuvi_license_status.txt
- Documents/dochoithuvi_rescue_report.txt
- Documents/dochoithuvi_bookdrop_status.txt

Ghi chú bản Clean DeviceInfo:
- Tên hiển thị trong KUAL: Dochoithuvi-Pro_v4.0.
- Mọi báo cáo TXT chính đều có khối THÔNG TIN MÁY: Serial, Serial prefix, Model, Firmware, Nhánh cảm ứng.
- Đã bỏ mục Chấm điểm Kindle và script kindle_score.sh.
- Đã bỏ mục Dọn dẹp báo cáo riêng; chức năng này chỉ còn trong Dọn dẹp & Cứu hộ.
- Đã bỏ asset Web Upload cũ vì Final hiện không còn menu gọi tính năng này.

## Web Upload v2.1

Mục `6. Chép sách qua Wi-Fi` đã thêm Web Upload Server:

1. Bấm `Bật Web Upload Server`.
2. Bấm `Hiển thị địa chỉ Upload`.
3. Mở địa chỉ dạng `http://Kindle-IP:8080/` trên điện thoại/máy tính cùng Wi-Fi.
4. Chọn file sách và upload.
5. Bấm `Nhập sách đã upload`.

Bản này dùng BusyBox `httpd` + CGI base64, tiện hơn FTP. Nên upload từng file một.

## v1.4 - Goodix Auto-Heal

Thêm vào `1. Kiểm tra / Fix lỗi cảm ứng`:
- Bật Goodix Auto-Heal
- Tắt Goodix Auto-Heal
- Trạng thái Auto-Heal
- Báo cáo Auto-Heal

Auto-Heal chạy nền, theo dõi `irq_info trigger-count`. Nếu IRQ tăng đột biến hơn 25 lần trong 60 giây, tool sẽ tự chạy Reset Goodix Ultra và ghi log.


## v1.5 - Goodix Guardian Pro

Đã bỏ Auto-Heal tự reset vì có rủi ro làm đơ/mất cảm ứng.

Thêm vào `1. Kiểm tra / Fix lỗi cảm ứng`:
- Goodix Guardian 10 phút: chỉ theo dõi IRQ, xuất TXT + CSV.
- Goodix Guardian 60 phút: theo dõi dài, phù hợp để bắt lỗi loạn cảm ứng ngẫu nhiên.
- Snapshot Goodix: chụp nhanh chip_info, driver_info, irq_info, power, pin/sạc.
- Ghost Touch Emergency Log: dùng khi máy bắt đầu loạn để ghi log khẩn cấp.
- Xóa báo cáo cảm ứng.

Thêm vào `7. Công cụ bí mật`:
- Dọn dẹp báo cáo
- Dọn thư mục Upload
- Dọn dẹp toàn bộ

File kết quả:
- Documents/goodix_guardian_10min.txt
- Documents/goodix_guardian_10min.csv
- Documents/goodix_guardian_60min.txt
- Documents/goodix_guardian_60min.csv
- Documents/goodix_snapshot.txt
- Documents/ghost_touch_emergency.txt


## v1.6 - Ghost Touch Diagnostic Engine thử nghiệm

Thêm vào `1. Kiểm tra / Fix lỗi cảm ứng`:
- Chẩn đoán Ghost Touch 10 phút
- Chẩn đoán Ghost Touch 30 phút

Tool tự theo dõi:
- IRQ Goodix
- AC online
- Điện áp USB
- Điện áp pin
- Dòng sạc hiện tại/trung bình
- Nhiệt độ pin
- Trạng thái pin

Sau khi chạy xong, tool đưa ra:
- Điểm cảm ứng
- Điểm nguồn sạc
- Điểm nhiệt độ
- Nguyên nhân nghi ngờ
- Độ tin cậy
- Hướng xử lý đề xuất

File kết quả:
- Documents/ghost_touch_diagnostic_10min.txt
- Documents/ghost_touch_diagnostic_10min.csv
- Documents/ghost_touch_diagnostic_30min.txt
- Documents/ghost_touch_diagnostic_30min.csv


## v1.7 - Menu rút gọn
Menu đã gom lại cho dễ dùng. `Kiểm tra pin` chỉ còn `Báo cáo & chẩn đoán pin`.


## v2.0 - User Friendly
Bỏ Kindle Doctor khỏi menu chính, thêm Thư viện sách và Màn hình khóa, đưa Báo cáo & Chẩn đoán pin ra menu chính.


## v2.1 - Menu tinh gọn + Báo cáo tiếng Việt

Đã bỏ khỏi menu chính:
- Kiểm tra nguồn sạc
- Thư viện sách
- Chép sách qua Wi-Fi
- Màn hình khóa

Menu còn:
1. Kiểm tra & Fix lỗi cảm ứng
2. Báo cáo & Chẩn đoán pin
3. Kiểm tra màn hình E-Ink
4. Công cụ bí mật

Các báo cáo chính xuất vào Documents đã được viết bằng tiếng Việt dễ đọc hơn.


## v2.2 - Touch Recovery
Thêm khôi phục cảm ứng nhanh, Reset Goodix Ultra + Reboot, Ghost Touch Guardian. Bỏ mục E-Ink tăng độ đậm/calibrate.


## v2.3 - Ghost Touch Guardian Modes

Thêm submenu `Ghost Touch Guardian Modes` trong phần cảm ứng:
- Chỉ ghi log
- Refresh màn hình
- Restart GUI
- Sleep/Wake
- Goodix Re-init thử nghiệm
- Trạng thái tất cả Guardian
- Dừng toàn bộ Guardian

Mục tiêu là test xem khi IRQ tăng cao, cách nào giúp giảm ghost touch tốt nhất mà ít ảnh hưởng trải nghiệm đọc.


## v3.0 - Khóa theo Serial Kindle

Bản này được khóa cho:
- Chủ sở hữu: Toyota Thanh Xuân
- Serial Kindle: G092AP0323406JH

Nếu copy sang Kindle khác, các script chính sẽ không chạy và xuất `Documents/dochoithuvi_license_status.txt`.


## v3.1 - Goodix IRQ Recovery
Thêm IRQ Recovery thủ công và Guardian IRQ Recovery để giảm ghost touch mà không Sleep/Wake/swipe unlock.


## v3.2 - Unlocked Clean

- Đã xóa khóa bản quyền theo Serial.
- Đã bỏ `Ghost Touch Guardian Modes`.
- Giữ lại hướng chính: Goodix IRQ Recovery và Guardian IRQ Recovery.


## v4.2 - Chặn cập nhật Kindle

Đổi `Rename OTA Bin` thành `Chặn cập nhật Kindle`.

Menu mới:
- Chặn cập nhật
- Bỏ chặn

Đã bỏ mục `Chép sách qua Wi-Fi` khỏi menu chính.


## v4.3 - Tách nhánh cảm ứng theo dòng máy
- Basic 2022/2024: IRQ Recovery.
- Paperwhite 10th Gen / PPW4: Goodix Rebind Recovery.
- Thêm nhận diện dòng máy và PPW4 Rebind Test.


## v4.6 - PPW4 Force Reset Combo

Thêm trong nhánh Paperwhite 10th Gen (PPW4):
- Force Reset Combo ngắn: unbind driver -> GPIO101 reset -> bind lại.
- Force Reset Combo sâu: giữ GPIO101 LOW lâu hơn trước khi bind lại.
- Trạng thái Force Reset.

Mục tiêu là xử lý lỗi `Device or resource busy` khi GPIO101 đang bị driver Goodix giữ.


## v4.7 - PPW4 Proc Touch Recovery

Thay nhánh PPW4 cũ bằng hướng mới dựa trên `/proc/touch`:
- Proc Touch Soft Recovery: lock -> unlock.
- Proc Touch Deep Recovery: lock lâu hơn rồi unlock.
- PPW4 Proc Guardian: theo dõi IRQ 127, khi tăng bất thường sẽ lock/unlock touch.
- Giữ Rebind Recovery làm fallback.


## v4.8 - PPW4 Proc Guardian v3

Thay cơ chế PPW4 cũ bằng Proc Guardian v3:
- Theo dõi IRQ 127 / gt9xx-ts.
- Khi IRQ burst: đọc trạng thái touch, lock, chờ IRQ ổn định, unlock.
- Ghi log chi tiết touch/IRQ trước-sau để xác nhận hiệu quả.
- Bỏ các hướng GPIO101 / Force Reset khỏi menu PPW4 vì bị kernel giữ GPIO.


## v4.9 - PPW4 Proc Guardian v3 Clean

Tinh gọn nhánh PPW4:
- Bỏ Command Probe, Rebind, Proc Explorer, Soft/Deep cũ, Lock/Unlock riêng.
- Giữ Proc Touch Recovery v3 thủ công, bật/tắt/trạng thái Guardian và trạng thái Proc Touch.

Tinh chỉnh:
- Ngưỡng IRQ burst nâng từ 80 lên 120 / 60 giây.
- Unlock có xác thực, thử lại tối đa 5 lần nếu trạng thái chưa về `Touch is unlocked`.
- Báo cáo ghi thêm thống kê recovery thành công/cần theo dõi.


## v5.0 - PPW4 Proc Guardian v4 Anti-Ghost / Anti-Stuck

- Không giữ locked lâu như v3.
- Nếu phát hiện touch bị locked ngoài ý muốn, tự unlock.
- Ngưỡng mềm 45 IRQ/phút để bắt sớm hiện tượng loạn.
- Ngưỡng mạnh 120 IRQ/phút để chạy cooldown locked 5 giây.
- Recovery dùng Double Pulse: lock/unlock hai lần, luôn xác thực trạng thái cuối là unlocked.


## v5.1 - PPW4 Basic-style Recovery

Mô phỏng Basic 2022: lock 1s -> unlock xác thực. Không giữ locked lâu, không double pulse mặc định, không cooldown locked.


## v5.2 - PPW4 True IRQ Lab

Thêm nhóm nghiên cứu `True IRQ Lab - PPW4` để tìm khả năng off IRQ thật:
- Dump sâu `/proc/irq/127`, `/sys/kernel/irq`, GPIO debug, device tree, module `gt9xx_ts`.
- Test `/proc/touch lock` có làm IRQ đứng thật không.
- Tìm node disable/enable IRQ nếu kernel expose.
- Test unbind/bind Goodix để xác nhận IRQ handler biến mất khi driver tháo ra.
- Probe GPIO99 IRQ pin, không đổi edge/value để tránh rủi ro.


## v5.3 - PPW4 Basic-style Fast Guardian

Dựa trên log thực tế:
- Basic-style recovery thành công 13/13 lần.
- Khi recovery, IRQ chỉ tăng thêm rất ít.
- Vấn đề chính là chu kỳ kiểm tra 60 giây còn chậm.

Thay đổi v5.3:
- Kiểm tra IRQ mỗi 10 giây.
- Ngưỡng trigger: IRQ tăng >25 / 10 giây.
- Recovery: /proc/touch lock 1 giây -> unlock xác thực.
- Cooldown sau recovery: 20 giây.
- Không giữ locked lâu, không double pulse mặc định.
- Tự dừng các Guardian cũ khi bật Fast Guardian để tránh xung đột.


## v5.4 - PPW4 Fast Guardian Tuned & Clean

Tinh chỉnh từ log thực tế:
- Trigger khi IRQ tăng >=25 / 10 giây.
- Giữ cơ chế lock 1s -> unlock xác thực.
- Giữ cooldown 20 giây.
- Bỏ True IRQ Lab và các mục PPW4 nghiên cứu/cũ khỏi menu.
- Xóa bớt script PPW4 thử nghiệm cũ trong gói để menu gọn, dễ dùng.


## v6.0 - PPW4 Ultimate Storm Shield + Serial License

Mục tiêu:
- Giữ hướng hiệu quả nhất: /proc/touch lock -> unlock xác thực.
- Chống cơn loạn nặng liên tiếp bằng Storm Mode.
- Tránh kẹt proc/touch bằng cách không đọc /proc/touch trong lúc lock.
- Thêm License theo serial máy.

Cơ chế Guardian:
- Kiểm tra IRQ mỗi 10 giây.
- Burst thường >=25/10s: lock 1s -> unlock xác thực, cooldown 20s.
- Storm >=300/10s hoặc nhiều burst liên tiếp: lock 3s -> unlock xác thực, cooldown 60s.
- Nếu thấy Touch is locked hoặc touch state timeout: force unlock ngay.

License:
- First-run Bind: lần chạy đầu tự khóa theo serial máy đang dùng.
- Nếu copy nguyên thư mục đã kích hoạt sang máy khác, license sẽ không khớp.
- Để khóa cứng theo từng khách hàng, dùng menu Xuất mã máy / Serial rồi tạo file `.license/license.key` theo token.


## v6.1 - Dọn menu PPW4

Thay đổi:
- Mục PPW4 chỉ còn 4 thao tác chính:
  1. Bật Ultimate Guardian
  2. Tắt Ultimate Guardian
  3. Trạng thái Ultimate Guardian
  4. Ultimate Recovery thủ công
- Đưa phần Serial/License ra mục riêng `Bản quyền / Serial`.
- Giữ nguyên cơ chế Serial Lock để hạn chế copy sang máy khác.


## v6.2 - Offline License File

Thay đổi:
- Bỏ cơ chế tự kích hoạt local.
- Guardian PPW4 yêu cầu file license hợp lệ.
- License gắn theo serial máy.
- Hỗ trợ 2 vị trí license:
  - license.key đặt trong thư mục extension
  - /mnt/us/documents/dochoithuvi_license.key
- Menu `Bản quyền / Serial` gồm:
  - Xuất mã máy / Serial
  - Kiểm tra License
  - Hướng dẫn cài license

Lưu ý bảo mật:
- Cách này chống copy nguyên thư mục sang máy khác ở mức thực tế với người dùng phổ thông.
- Với máy jailbreak, người có kỹ năng sửa shell script vẫn có thể phá nếu truy cập được mã nguồn.


## v6.3 - License All Functional Tools

Thay đổi:
- Tất cả script chức năng trong bin đã được chèn kiểm tra license trước khi chạy.
- Không chỉ Ultimate Guardian, các tool kiểm tra/fix/chặn cập nhật/báo cáo chức năng đều yêu cầu license hợp lệ.
- Chỉ để mở các mục cần thiết để kích hoạt/quản lý:
  - Xuất mã máy / Serial
  - Kiểm tra License
  - Hướng dẫn cài license
  - Tắt Guardian / Xóa log nếu có
- Thêm mục `Danh sách tool đã khóa` trong `Bản quyền / Serial`.

Số script đã khóa license: 111
Số script để mở an toàn: 8


## v6.4 - PPW4 Fast Stable rollback

Thay đổi:
- Gỡ thuật toán Ultimate Storm cho PPW4 vì log thực tế cho thấy dễ gây nhảy cảm ứng hơn.
- Quay lại cơ chế ổn của v5.4:
  - kiểm tra IRQ mỗi 10 giây
  - trigger >=25/10s
  - lock 1 giây -> unlock xác thực
  - cooldown 20 giây
- Giữ license toàn bộ tool từ v6.3.
- Menu PPW4 vẫn gọn 4 mục.
- Báo cáo mới:
  - /documents/ppw4_faststable_guardian_report.txt
  - /documents/ppw4_faststable_guardian_status.txt


## v6.5 - Basic 2022 / Basic 2024 IRQ Recovery Fast 30s

Tinh chỉnh dựa trên log Basic 2022 mới:
- Guardian IRQ chuyển từ 60 giây sang 30 giây để bắt burst sớm hơn.
- Ngưỡng: >30 IRQ / 30 giây.
- Sau recovery sẽ kiểm tra thêm 30 giây.
- Nếu sau recovery IRQ vẫn tăng >30, tự chạy follow-up recovery 1 lần.
- Cooldown sau xử lý: 60 giây.
- Menu Basic gọn còn 4 mục.
- Vẫn giữ cơ chế license toàn bộ tool từ v6.4.

Báo cáo:
- /documents/guardian_irq_recovery_report.txt
- /documents/guardian_irq_recovery_status.txt


## v6.6 - Fix chặn cập nhật Kindle / renameotabin

Sửa lỗi:
- Không gọi script renameotabin lồng thư mục bằng đường dẫn hardcode nữa.
- Tích hợp trực tiếp cơ chế đổi tên /usr/bin/otaupd và /usr/bin/otav3.
- Thêm trạng thái chặn cập nhật trước khi chạy.
- Block/Restore idempotent: chạy lại không gây lỗi nếu đã chặn hoặc đã bỏ chặn.
- Có fallback remount root rw/ro nếu mntroot không hoạt động.
- Lưu báo cáo:
  - /documents/trang_thai_chan_cap_nhat_kindle.txt
  - /documents/chan_cap_nhat_kindle.txt
  - /documents/bo_chan_cap_nhat_kindle.txt


## v6.7 - Clean bin

Dọn thư mục bin:
- Chỉ giữ script đang được menu gọi trực tiếp và dependency bắt buộc.
- Giữ `dochoithuvi_license_common.sh`.
- Xóa các script thử nghiệm/cũ không còn xuất hiện trong menu.
- Số script giữ lại: 27
- Số script đã xóa: 94
- Báo cáo chi tiết: `BIN_CLEAN_REPORT.txt`


## v6.8 - KOReader tích hợp + đánh số menu + dọn tiến trình cũ

Thay đổi:
- Tích hợp KOReader v2026.03 vào payload của tool.
- KOReader chỉ mở qua menu Dochoithuvi-Pro và yêu cầu license hợp lệ.
- Thêm menu KOReader:
  - Mở KOReader
  - Cài / Cập nhật KOReader
  - Trạng thái KOReader
- Đánh số thứ tự toàn bộ mục menu.
- Xóa thư mục renameotabin cũ lồng trong gói.
- Dọn bin còn 30 script cần thiết, xóa 0 script thừa/cũ.
- Giữ PPW4 Fast Stable, Basic IRQ 30s, OTA Block fixed, License all tools.


## v6.9 - Lite / bỏ KOReader

Thay đổi:
- Xóa toàn bộ payload KOReader để giảm dung lượng gói.
- Xóa menu KOReader.
- Xóa script KOReader trong bin.
- Đánh số lại menu.
- Dọn bin còn 27 script cần thiết.
- Giữ nguyên PPW4 Fast Stable, Basic IRQ 30s, License toàn bộ tool, OTA Block fixed.


DOCHOITHUVI-PRO v1.7
==========================================

Bản đóng gói sạch từ Final v1.0 First Release, dựa trên v6.9 Lite No KOReader.

Có trong bản Final:
- PPW4 Fast Stable Guardian: /proc/touch lock 1s -> unlock xác thực.
- Basic 2022 / Basic 2024 IRQ Guardian Final: kiểm tra 30s, recovery thường/nặng, follow-up tối đa 3 vòng.
- License toàn bộ tool.
- Chặn cập nhật Kindle fixed: đổi otaupd/otav3 sang .bck.
- Báo cáo kỹ thuật tổng hợp: /documents/dochoithuvi_final_full_report.txt
- Cứu hộ nhanh: dừng guardian cũ, unlock touch, bật lại IRQ nếu cần.
- Chẩn đoán pin, E-Ink, dọn báo cáo trong nhóm cứu hộ, serial/license.
- Menu đã đánh số lại sau khi bỏ Chấm điểm Kindle và mục dọn báo cáo trùng lặp.
- Không tích hợp KOReader để giữ gói nhẹ.

Khuyến nghị test Final:
1. Cài tool.
2. Kiểm tra License.
3. Chạy Báo cáo kỹ thuật tổng hợp.
4. Với PPW4: bật PPW4 Fast Stable.
5. Với Basic 2022/2024: bật Basic IRQ Guardian.
6. Nếu có lỗi/kẹt: chạy Dọn dẹp & Cứu hộ -> Cứu hộ nhanh.
7. Muốn xóa báo cáo cũ: chạy Dọn dẹp & Cứu hộ -> Xóa toàn bộ báo cáo cũ.


## v1.2 - Menu tinh gọn + Kho sách
- Đổi Báo cáo kỹ thuật tổng hợp thành nút bấm trực tiếp ở menu chính.
- Báo cáo pin chỉ còn xuất một file: Documents/bao_cao_chan_doan_pin.txt.
- Bỏ Hướng dẫn cài license và Danh sách tool đã khóa khỏi menu Bản quyền / Serial.
- Đổi Cứu hộ chung thành Chẩn đoán & Cứu hộ cảm ứng chung.
- Thêm Quản lý kho sách với link cloud cá nhân và nguồn sách miễn phí hợp pháp.


## v1.3 - Đồng bộ kho sách trực tiếp
- Đổi mục Quản lý kho sách cá nhân từ mở trình duyệt sang đồng bộ trực tiếp bằng curl/wget trong KUAL.
- Danh sách đồng bộ dùng file Documents/dochoithuvi_book_sync_list.txt hoặc book_sync_list.txt trong thư mục extension.
- Định dạng khuyến nghị: TenFile.epub|https://link-tai-truc-tiep.
- Kho sách miễn phí hợp pháp chỉ xuất danh sách nguồn, không mở trình duyệt Kindle.


## v1.4 - BookDrop Wi-Fi
- Đổi Quản lý kho sách sang cơ chế BookDrop Wi-Fi giống BooxDrop.
- KUAL bật server upload nội bộ bằng BusyBox/httpd trên cổng 8080.
- Điện thoại/máy tính cùng Wi-Fi mở http://Kindle-IP:8080/ để gửi sách.
- Địa chỉ kindle.local:8080 chỉ là tùy chọn nếu mạng hỗ trợ .local; IP nội bộ là cách chắc ăn nhất.
- Sách upload lưu trực tiếp vào /mnt/us/documents.


## v1.5 - BookDrop gọn
- Bỏ mục Kho sách miễn phí hợp pháp khỏi Quản lý kho sách.
- Mục 09 chỉ còn Bật BookDrop, Hiển thị địa chỉ, Tắt BookDrop.


## v1.6 - Basic IRQ Guardian chống chạy trùng
- Thêm Thiết bị vào khối THÔNG TIN MÁY, map MT8110 Bellatrix thành Kindle Basic 11th Gen (2022).
- Nâng Basic IRQ Guardian: PID + lock file, kill hard tiến trình cũ, cooldown 90s, storm cooldown 180s.
- Giảm follow-up tối đa còn 2 vòng để tránh recovery chồng liên tục.
- Status Guardian hiển thị lock/PID/số tiến trình nghi ngờ.


## v1.7 - BookDrop fallback netcat
- Đổi tên hiển thị KUAL thành Dochoithuvi-Pro_v1.7, bỏ chữ Final.
- BookDrop kiểm tra httpd applet trước khi chạy.
- Nếu Kindle thiếu httpd nhưng có nc/netcat, BookDrop dùng server netcat dự phòng.
- Status BookDrop hiển thị engine đang dùng và log lỗi applet nếu có.


DOCHOITHUVI-PRO v4.1 - BOOKDROP HOT + TOOL-KUAL VIỆT HÓA
========================================================

Thay đổi chính:
1. Đưa BookDrop lên mục 02 trên menu chính.
2. Nâng cấp BookDrop:
   - Tab Gửi sách trực tiếp vào Kindle.
   - Tab EPUB Send to Kindle.
   - Chọn EPUB/DOC/DOCX rồi bấm gửi qua Send to Kindle bằng Web Share API nếu thiết bị hỗ trợ.
   - Không cần mở web amazon.com/sendtokindle trong luồng chính.
   - Vẫn có fallback email Kindle nếu trình duyệt không hỗ trợ chia sẻ file.
3. Thêm Quản lý kho sách cá nhân:
   - File cấu hình: /mnt/us/documents/dochoithuvi_bookcloud_links.txt
   - Link cloud folder Google Drive/Dropbox/Terabox sẽ hiện trong BookDrop để mở nhanh.
   - Đồng bộ tự động về Kindle hoạt động tốt nhất với link tải trực tiếp tới file sách.
4. Tích hợp Tool-KUAL:
   - Đã copy toàn bộ Repository-main vào tools/Tool-KUAL.
   - Thêm menu cài/gỡ tool bằng tiếng Việt.
   - Tổng tool tích hợp: 28.
   - Một số tool cần Wi-Fi để tải dữ liệu từ Internet.
5. Giữ nguyên license/check serial hiện có.

Lưu ý:
- Trình duyệt không thể tự đính kèm file EPUB vào email trên mọi thiết bị. Trên Android/iOS mới, nút Send to Kindle dùng Web Share API để mở Kindle app/email/share sheet.
- Google Drive/Dropbox/Terabox folder thường không phải direct download, nên auto sync chỉ chắc chắn với link tải trực tiếp.


DOCHOITHUVI-PRO v4.1 - PATCH TOGGLEADS + CLEANUP MẠNH
======================================================

Thay đổi theo yêu cầu:
1. Xóa mục Tool-KUAL mở rộng khỏi menu chính.
2. Trong payload Tool-KUAL chỉ giữ lại ToggleAds, xóa 27 tool còn lại.
3. Đưa ToggleAds ra màn hình chính thành mục:
   08. Gỡ quảng cáo Kindle
   - Cài ToggleAds / Gỡ quảng cáo
   - Gỡ ToggleAds / Hoàn tác
   - Trạng thái ToggleAds
4. Cải tiến xóa báo cáo:
   - Thêm cleanup_reports_strong.sh
   - Xóa report/log/status/PID chết mạnh hơn.
   - Không xóa sách, license.key, BookCloud config, SendToKindle config.
   - Các menu xóa báo cáo đã được trỏ sang bản cleanup mạnh.
5. Send to Kindle:
   - Giữ Web Share API + fallback email Kindle.
   - Chưa bật gửi SMTP thẳng từ web 192.168.x.x vì cần SMTP password/API key, rủi ro bảo mật và không chắc Kindle có TLS SMTP ổn định.
   - Đã thêm file SENDTOKINDLE_DIRECT_RESEARCH.txt để ghi chú hướng nghiên cứu.


DOCHOITHUVI-PRO v4.2 - ONLINE UPDATE CÓ BẢN QUYỀN
==================================================

Đã thêm cơ chế update online kiểu KOReader, nhưng có khóa bản quyền:

Menu mới:
- Cập nhật Online có bản quyền
  01. Kiểm tra bản mới
  02. Tải & cài bản mới
  03. Khôi phục backup trước đó
  04. Trạng thái cập nhật

Cơ chế:
1. Trước khi check/update, tool gọi require_license.
2. Nếu không có license.key hợp lệ, không cho tải manifest/update.
3. Manifest đặt trên GitHub/raw server.
4. Update tải file ZIP về /mnt/us/.dochoithuvi_update.
5. Nếu manifest có sha256, tool sẽ kiểm tra SHA256 trước khi cài.
6. Trước khi cài, tool backup extension hiện tại.
7. Có mục restore backup nếu bản mới lỗi.

File cấu hình:
- bin/online_update_config.sh

Manifest mẫu:
version=4.3
build=20260630
channel=stable
min_version=4.2
root_folder=Dochoithuvi-Pro-Secret-Edition
url=https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/dochoithuvi-pro-updates/main/Dochoithuvi-Pro_v4.3.zip
sha256=...
note=Noi dung cap nhat

Lưu ý:
- Sếp cần sửa MANIFEST_URL trong bin/online_update_config.sh trước khi phát hành thật.
- Kindle cần Wi-Fi và có curl/wget/busybox wget.
- Không có key bản quyền thì không update được.


DOCHOITHUVI-PRO v4.3 - SECURE ONLINE UPDATER
==============================================

Nâng cấp bảo mật so với v4.2:
1. Signed manifest:
   - manifest.txt phải đi kèm manifest.sig.
   - Tool verify bằng RSA public key trong secure_update_public.pem.
   - Private key không nằm trong tool khách.

2. Không fallback insecure:
   - Nếu thiếu openssl, thiếu manifest.sig hoặc chữ ký sai, updater dừng.
   - Không tự chuyển về kiểu chỉ check SHA256.

3. License gate:
   - Phải có license.key hợp lệ mới check/update.
   - Check license trước khi tải manifest/update.
   - Check lại license sau khi cài, nếu lỗi thì rollback.

4. Anti-tamper cơ bản:
   - SHA256 update.zip bắt buộc.
   - Chặn downgrade/min_version.
   - Kiểm tra path traversal trong ZIP.
   - Backup trước khi cài.
   - Restore backup riêng.

5. Blacklist license online:
   - Manifest có thể khai báo blacklist_url.
   - Blacklist có thể chứa serial hoặc license_id, mỗi dòng một mã.
   - Nếu license nằm trong blacklist thì không update.

Menu:
- Cập nhật Online bảo mật
  01. Kiểm tra bản mới có chữ ký
  02. Tải & cài bản mới bảo mật
  03. Khôi phục backup trước đó
  04. Trạng thái Secure Updater

Lưu ý:
- Kindle cần có openssl, sha256sum, unzip và curl/wget/busybox wget.
- Nếu thiếu openssl, bản secure sẽ báo lỗi thay vì update không an toàn.


DOCHOITHUVI-PRO v4.4 - REPORT UPLOADER
======================================

Thêm cơ chế khách gửi report loạn cảm ứng về server:

Menu mới:
- Gửi report loạn cảm ứng
  01. Tạo gói report cảm ứng
  02. Upload report lên server
  03. Trạng thái upload report

Cơ chế:
1. Yêu cầu license.key hợp lệ trước khi tạo/upload report.
2. Thu thập report/log kỹ thuật cảm ứng: guardian, PPW4, Goodix, touch, dmesg, /proc/interrupts, input devices, battery/df/uptime.
3. Không copy sách trong /documents.
4. Không upload license.key nguyên bản.
5. Tạo gói local: /documents/dochoithuvi_touch_report_<serial>_<time>.tar.gz
6. Nếu cấu hình server và có curl, tool upload bằng HTTPS POST multipart.

File cấu hình:
- bin/report_upload_config.sh

Server:
- Dùng bộ Dochoithuvi_Report_Upload_Server_Template_v4.4_SELLER_ONLY.zip
- Sửa REPORT_UPLOAD_URL trỏ đến upload.php.


DOCHOITHUVI-PRO v4.4 - CLEAN MENU PATCH
=======================================

Sửa theo yêu cầu:
1. ToggleAds giữ trong KUAL, không làm icon/extension riêng ngoài KUAL.
2. Gửi report loạn cảm ứng chỉ còn 1 nút duy nhất:
   01. Kiểm tra & Fix lỗi cảm ứng -> Gửi report loạn cảm ứng
3. Xóa menu report riêng khỏi màn hình chính.
4. Cập nhật Online bảo mật đã được đưa xuống cuối menu chính.
5. Xóa bớt script .sh thừa của version cũ:
   - report_touch_collect.sh
   - report_upload_status.sh
   - wrapper Tool-KUAL cũ nếu còn
   - wrapper module standalone cũ nếu còn

Report upload vẫn tự gom report rồi upload khi bấm một nút duy nhất.


DOCHOITHUVI-PRO v4.4.2 - LOCAL REPORT + FAST BOOKDROP
=====================================================

Thay đổi:
1. Bỏ upload report loạn cảm ứng lên server.
2. Thay bằng 1 nút: 01. Kiểm tra & Fix lỗi cảm ứng -> Tạo báo cáo loạn cảm ứng.
3. File báo cáo tạo trong /documents: dochoithuvi_touch_report_*.tar.gz để khách gửi trực tiếp.
4. BookDrop bỏ các mục: Hiển thị địa chỉ BookDrop, Email Send to Kindle, Chẩn đoán mạng BookDrop.
5. Xóa .sh thừa liên quan các mục đã bỏ: bookdrop_lan_diagnostic.sh, bookdrop_status.sh, report_touch_upload.sh, report_upload_common.sh, report_upload_config.sh, sendtokindle_email_status.sh.
6. Giảm sleep/chờ trong bookdrop_start.sh để bật BookDrop nhanh hơn.
