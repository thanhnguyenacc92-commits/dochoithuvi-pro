/**
 * Dochoithuvi BookCloud Manifest - Google Apps Script
 * Deploy Web App and use URL in BookCloud:
 * manifest:https://script.google.com/macros/s/XXXX/exec|Kho Google Drive
 */
const FOLDER_ID = 'PASTE_GOOGLE_DRIVE_FOLDER_ID_HERE';

function doGet(e) {
  const folder = DriveApp.getFolderById(FOLDER_ID);
  const files = folder.getFiles();
  const lines = [
    '# Dochoithuvi BookCloud manifest',
    '# format: URL|filename'
  ];

  while (files.hasNext()) {
    const file = files.next();
    const name = file.getName();

    if (!/\.(azw3|azw|mobi|prc|kfx|pdf|txt|epub|cbz|cbr)$/i.test(name)) {
      continue;
    }

    const url = 'https://drive.google.com/file/d/' + file.getId() + '/view';
    lines.push(url + '|' + name);
  }

  return ContentService
    .createTextOutput(lines.join('\n'))
    .setMimeType(ContentService.MimeType.TEXT);
}
