# Dochoithuvi-Pro v6.8.6 FinalGate

## Menu

```text
01. FinalGate MicroShield — START
03. Gửi báo cáo Cloud — tool vẫn chạy
05. Báo cáo & Chẩn đoán pin
06. MagicAds
07. Dọn dẹp báo cáo/log cũ
09. Cập nhật phiên bản mới
```

Mục 02 đã được bỏ khỏi menu. Script STOP vẫn được giữ nội bộ để updater và cơ
chế fail-open có thể dừng an toàn khi thật sự cần thay phiên bản.

## ORPHAN_CONTACT_END_BURST_GATE

Báo cáo máy `G092AQ0541030C30` cho thấy contact tại vùng trên bên phải
`X≈1016, Y≈144`, sau đó xuất hiện chuỗi `CONTACT_END` HIGH không có
`CONTACT_START` tương ứng và engine cũ không mở gate.

Bản này chạy thêm một binary ARM tĩnh đọc raw Goodix song song:

- nhận `ABS_MT_TRACKING_ID=-1` khi slot vốn không active là orphan END;
- gán vùng theo lưới 8 × 12;
- cho phép dùng tọa độ cuối của slot trong tối đa 1500 ms;
- đủ 3 orphan END cùng vùng trong 1200 ms sẽ grab 650 ms;
- tối đa 4 orphan gate trong 60 giây, sau đó monitor-only 60 giây;
- không uinput, không replay touch, không ghi IRQ;
- STOP/crash đóng fd nên nhả EVIOCGRAB ngay.

Watchdog tự khởi động lại Orphan Shield nếu helper thoát ngoài ý muốn. Các tag
orphan gate không được dùng để phán nhầm native engine đang kẹt MICRO_GATE.

## Gửi Cloud khi tool vẫn chạy

Mục 03 chỉ tạo snapshot tại thời điểm bấm và gửi trong nền:

- không gọi STOP;
- FinalGate tiếp tục chạy;
- không thay đổi Wi-Fi;
- không xóa báo cáo gốc;
- retry queue cũ, thử tối đa 3 lần;
- gzip file lớn hơn 2 MB;
- giữ queue nếu mạng hoặc Apps Script lỗi.

Vì report vẫn đang tăng, bản gửi là một prefix nhất quán tại thời điểm snapshot.
Lần gửi sau hoặc báo cáo sau khi dừng sẽ chứa phần phát sinh tiếp theo.

Token riêng vẫn đọc từ:

```text
/mnt/us/documents/dochoithuvi_drive_token.conf
```

## Cập nhật

OTA `8.5`, tag `v6.8.6-finalgate-fix4`. Updater xác minh chữ ký và SHA-256,
giải nén staging, kiểm tra BUILD_MANIFEST, chuyển nguyên thư mục cũ vào backup,
đưa cây mới sạch vào active và rollback tự động nếu hậu kiểm thất bại.
